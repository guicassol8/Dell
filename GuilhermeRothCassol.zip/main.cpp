#include <iostream>
#include <unordered_set>
#include <unordered_map>
#include <vector>
#include "Interface.hpp"


using namespace std;

int main (){
	Interface interface = Interface();
	interface.menu();
	return 0;
}
